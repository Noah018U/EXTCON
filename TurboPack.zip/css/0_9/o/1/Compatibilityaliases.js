const extensions = {
  // maps old path to new path
  "/LukeManiaStudios/ClonesPlus.js": "/Lily/ClonesPlus.js",
  "/LukeManiaStudios/CommentBlocks.js": "/Lily/CommentBlocks.js",
  "/LukeManiaStudios/lmsutils.js": "/Lily/lmsutils.js",
  "/LukeManiaStudios/LooksPlus.js": "/Lily/LooksPlus.js",
  "/LukeManiaStudios/McUtils.js": "/Lily/McUtils.js",
  "/LukeManiaStudios/MoreTimers.js": "/Lily/MoreTimers.js",
  "/LukeManiaStudios/TempVariables.js": "/Lily/TempVariables.js",
  "/LukeManiaStudios/TempVariables2.js": "/Lily/TempVariables2.js",
};

module.exports = extensions;
